from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session

from werkzeug.security import check_password_hash, generate_password_hash

from helpers import login_required

import requests
from bs4 import BeautifulSoup

import copy


app = Flask(__name__)

app.config["TEMPLATES_AUTO_RELOAD"] = True

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQL("sqlite:///music.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    user_id = session["user_id"]

    favorite_1 = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)

    if len(favorite_1) == 0:
        not_set = "好きなアーティストを選んでください。"
        return render_template("index.html", artist = not_set)

    elif len(favorite_1) == 1:
        not_set = "好きなアーティストを選んでください。"
        artist = favorite_1[0]["favorite_1"]
        return render_template("index.html", artist =artist, artist1 = not_set)

    elif len(favorite_1) == 2:
        not_set = "好きなアーティストを選んでください。"
        artist = favorite_1[0]["favorite_1"]
        artist1 = favorite_1[1]["favorite_1"]
        return render_template("index.html", artist =artist, artist1 = artist1, artist2= not_set )

    else:
        artist = favorite_1[0]["favorite_1"]
        artist1 = favorite_1[1]["favorite_1"]
        artist2 = favorite_1[2]["favorite_1"]
        return render_template("index.html", artist =artist, artist1 = artist1, artist2= artist2 )


@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()

    if request.method == "POST":
        if not request.form.get("username"):
            message = "ユーザーネームが入力されていません。"
            return render_template("error.html", message = message)

        elif not request.form.get("password"):
            message = "パスワードが入力されていません。"
            return render_template("error.html", message = message)

        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            message = "ユーザーネームもしくはパスワードの入力が間違っています。"
            return render_template("error.html", message = message)

        session["user_id"] = rows[0]["id"]

        flash("ログインされました。")
        return redirect("/")

    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()

    return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":
        if not request.form.get("username"):
            message = "ユーザーネームが入力されていません。"
            return render_template("error.html", message = message)

        elif not request.form.get("password"):
            message = "パスワードが入力されていません。"
            return render_template("error.html", message = message)

        elif request.form.get("password") != request.form.get("confirmation"):
            message = "パスワードの入力が一致しません。"
            return render_template("error.html", message = message)

        rows = db.execute("SELECT username FROM users WHERE username = ?", request.form.get("username"))

        if len(rows) == 1:
            message = "ユーザーネームがすでに使われています。"
            return render_template("error.html", message = message)

        hash = generate_password_hash(request.form.get("password"))
        db.execute("INSERT INTO users(username, hash) VALUES(?, ?)", request.form.get("username"), hash)

        return redirect("/")

    else:
        return render_template("register.html")


@app.route("/favorites", methods=["GET", "POST"])
@login_required
def favorites():
    user_id = session["user_id"]
    favorite = db.execute("SELECT favorite_1 FROM mypage WHERE user_id=?", user_id)

    if request.method == "POST" and len(favorite) <= 2:

        artist_1 = request.form.get("artist_1")

        url = f"https://www.uta-net.com/search/?target=art&type=in&Keyword={artist_1}"

        site = requests.get(url)

        data = BeautifulSoup(site.text, 'html.parser')

        elems = data.select('.fw-bold')

        list_artists = []
        for elem in elems:
            list_artists.append(elem.text)

        return render_template("favorite_1.html", elems = list_artists)

    elif request.method == "GET" and len(favorite) <= 2:
        return render_template("favorites.html")

    elif request.method == "POST" and len(favorite) >= 2:
        return render_template("favorites.html")

    else:
        message ="お気に入りのアーティストは既に選ばれています。"
        return render_template("error.html", message = message)


@app.route("/favorite_1", methods=["GET","POST"])
@login_required
def favorite_1():
    if request.method == "POST":
        user_id = session["user_id"]
        element = request.form.get('favartist')
        db.execute("INSERT INTO mypage(user_id, favorite_1) VALUES(?,?)", user_id, element)
        return redirect("/")

    else:
        return render_template("favorite_1.html")


@app.route("/delete_favorite", methods=["GET", "POST"])
@login_required
def delete_favorite():
    if request.method == "GET":
        user_id = session["user_id"]
        deleted_elements = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)
        if len(deleted_elements)==3:
            delete_element = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)[0]["favorite_1"]
            delete_element1 = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)[1]["favorite_1"]
            delete_element2 = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)[2]["favorite_1"]
            return render_template("delete_favorite.html", delete_element = delete_element, delete_element1 = delete_element1, delete_element2 = delete_element2)

        elif len(deleted_elements)==2:
            delete_element = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)[0]["favorite_1"]
            delete_element1 = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)[1]["favorite_1"]
            delete_element2 = "-"
            return render_template("delete_favorite.html", delete_element = delete_element, delete_element1 = delete_element1, delete_element2 = delete_element2)

        elif len(deleted_elements)==1:
            delete_element = db.execute("SELECT favorite_1 FROM mypage WHERE user_id = ?", user_id)[0]["favorite_1"]
            delete_element1 = "-"
            delete_element2 = "-"

            return render_template("delete_favorite.html", delete_element = delete_element, delete_element1 = delete_element1, delete_element2 = delete_element2)

        else:
            message = "削除する項目がありません。"
            return render_template("error.html", message=message)

    else:
        if request.form.get('delete_element')=="-":
            message = "削除する項目がありません。"
            return render_template("error.html", message = message)

        else:
            user_id = session["user_id"]
            deleted_element = request.form.get('delete_element')
            db.execute("DELETE FROM mypage WHERE favorite_1=? AND user_id=? ", deleted_element, user_id)
            flash("削除されました。")
            return redirect("/")


@app.route("/others_favorite", methods=["GET", "POST"])
@login_required
def others_favorite():
    if request.method == "GET":
        user_id = session["user_id"]
        others_username = db.execute("SELECT username FROM users WHERE id != ?", user_id)
        users = len(others_username)
        id_users = db.execute("SELECT id FROM users WHERE id != ?", user_id)
        user_id_mypage = db.execute("SELECT user_id FROM mypage WHERE user_id != ?", user_id)

        id_users_idonly = []
        user_id_mypage_idonly = []
        user_id_mypage_list = []
        usernameonly_list=[]

        for i in user_id_mypage:
            if i not in user_id_mypage_list:
                user_id_mypage_list.append(i)

        # idのみを格納する配列を作成 （users データベース）
        for i in id_users:
            for j in i.values():
                id_users_idonly.append(j)

        # idのみを格納する配列を作成 （mypage データベース）
        for i in user_id_mypage_list:
            for j in i.values():
                user_id_mypage_idonly.append(j)

        # username のみを格納した配列を作成
        for i in range(users):
            for j in id_users[i].values():
                username = db.execute("SELECT username FROM users WHERE id = ?", j)
                for k in username[0].values():
                    usernameonly_list.append(k)

        # username　とfavrote 3つを格納した配列を作成
        fav = []
        fav_all = []

        for i in range(users):
            if id_users_idonly[i] not in user_id_mypage_idonly:
                fav.append(usernameonly_list[i])
                for j in range(3):
                    fav.append("-")
                temp = copy.deepcopy(fav)
                fav_all.append(temp)
                fav.clear()

            else:
                fav.append(usernameonly_list[i])
                ofa_each = db.execute("SELECT favorite_1 FROM mypage WHERE user_id IN (SELECT id FROM users WHERE id =? )", id_users_idonly[i])
                if len(ofa_each)==1:
                    for k in ofa_each:
                        for l in k.values():
                            fav.append(l)
                    for j in range(2):
                        fav.append("-")
                    temp = copy.deepcopy(fav)
                    fav_all.append(temp)
                    fav.clear()

                elif len(ofa_each)==2:
                    for k in ofa_each:
                        for l in k.values():
                            fav.append(l)
                    fav.append("-")
                    temp = copy.deepcopy(fav)
                    fav_all.append(temp)
                    fav.clear()

                else:
                    for k in ofa_each:
                        for l in k.values():
                            fav.append(l)
                    temp = copy.deepcopy(fav)
                    fav_all.append(temp)
                    fav.clear()

        fav_all_length = len(fav_all)
        return render_template("others_favorite.html", fav_all=fav_all, fav_all_length=fav_all_length)

    else:
        return render_template("error.html")

